require "test_helper"

class FriendTest < ActiveSupport::TestCase
  
end
