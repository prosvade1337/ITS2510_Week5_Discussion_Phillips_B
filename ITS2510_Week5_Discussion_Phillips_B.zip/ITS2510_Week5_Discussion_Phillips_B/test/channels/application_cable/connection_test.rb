require "test_helper"

class ApplicationCable::ConnectionTest < ActionCable::Connection::TestCase

end
