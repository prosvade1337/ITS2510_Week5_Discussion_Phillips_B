class Friend < ApplicationRecord
  belongs_to :user
end
