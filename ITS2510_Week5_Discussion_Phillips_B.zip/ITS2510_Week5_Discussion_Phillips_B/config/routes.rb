Rails.application.routes.draw do
  devise_for :users
  resources :friends
  get 'user/sign_out'
  get 'home/about'
  root 'friends#index'

end
